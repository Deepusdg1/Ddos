import subprocess
subprocess.Popen("python3 api.py", shell=True)